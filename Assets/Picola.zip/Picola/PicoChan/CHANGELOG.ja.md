# Changelog
Changelog format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.1.0] - 2024-10-02
### Changed
- `Unity-Chan Toon Shader 2.0 (UTS2)` から `Unity Toon Shader (UTS3)` に変更
### Removed
- URP-2020.3+.unitypackage を削除

## [1.0.0] - 2022-04-26
### Added
- 初回リリース
