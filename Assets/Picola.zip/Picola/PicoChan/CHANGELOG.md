# Changelog
Changelog format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.1.0] - 2024-10-02
### Changed
- Changed from `Unity-Chan Toon Shader 2.0 (UTS2)` to `Unity Toon Shader (UTS3)`
### Removed
- Removed URP-2020.3+.unitypackage

## [1.0.0] - 2022-04-26
### Added
- First release
